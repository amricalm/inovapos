<div class="grid_12">
    <div class="module">
    	<h2 style="text-align: center;"><span>Sinkronisasi</span></h2>
        <table class="tablesorter">
            <tr>
                <td style="width:25%;text-align:center;">
                    <a href="#" id="link_stok">
                    <img src="<?php echo $base_img ?>/stock-icon.png" id="stok" />
                    <br />
                    Stok
                    </a>
                </td>
                <td style="width:75%;text-align:left;vertical-align:middle">
                    <a class="submit-green" href="<?php echo base_url() ?>index.php/sinkronisasi/mutasi_barang?iframe=true&width=100%&height=100%" id="display_mutasi_barang" rel="prettyPhoto[iframe]">Kirim Stok</a>
                </td>
            </tr>
        </table>
    </div> <!-- End .module -->
</div>