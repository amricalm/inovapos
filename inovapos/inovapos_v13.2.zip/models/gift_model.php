<?php

class Gift_model extends CI_Model
{
    //function __construct
}

?>