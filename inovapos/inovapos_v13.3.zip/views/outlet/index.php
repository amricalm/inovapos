<div class="grid_12">
    <div class="module">
         <h2><span>Outlet</span></h2>
         <div class="module-body">
            <form action="">
                <p>
                    <label>Nama Outlet</label>
                    <input type="text" class="input-long" name="outlet_nm" id="outlet_nm" />
                    <!--<span class="notification-input ni-correct">This is correct, thanks!</span>-->
                </p>
                <p>
                    <label>Alamat</label>
                    <textarea rows="7" cols="90" class="input-long" name="outlet_alamat" id="outlet_alamat"></textarea>
                </p>
                <p>
                    <label>Kelurahan</label>
                    <input type="text" class="input-long" name="outlet_kelurahan" id="outlet_kelurahan" />
                </p>
                <p>
                    <label>Kecamatan</label>
                    <input type="text" class="input-long" name="outlet_kecamatan" id="outlet_kecamatan" />
                </p>
                <p>
                    <label>Kota</label>
                    <input type="text" class="input-long" name="outlet_kota" id="outlet_kota" />
                </p>
                <p>
                    <label>Kode POS</label>
                    <input type="text" class="input-long" name="outlet_kodepos" id="outlet_kodepos" />
                </p>
                <fieldset>
                    <input class="submit-green" type="submit" value="Submit" /> 
                    <input class="submit-gray" type="submit" value="Cancel" />
                </fieldset>
            </form>
         </div>
    </div>
	<div style="clear:both;"></div>
</div>