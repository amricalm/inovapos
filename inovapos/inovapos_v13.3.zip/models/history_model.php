<?php

class History_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    function simpan_kasir($data)
    {
        return $this->db->insert('history_ac_tjual',$data);
    }
    function simpan_kasir_dtl($data)
    {
        return $this->db->insert('history_ac_tjual_dtl',$data);
    }
    function simpan_kasir_dtl_imei($data)
    {
        return $this->db->insert('history_ac_tjual_dtl_imei',$data);
    }
    function simpan_pindah($data)
    {
        return $this->db->insert('history_im_tpindah_barang',$data);
    }
    function simpan_pindah_dtl($data)
    {
        return $this->db->insert('history_im_tpindah_barang_dtl',$data);
    }
    function simpan_pindah_dtl_imei($data)
    {
        return $this->db->insert('history_im_tpindah_barang_dtl_imei',$data);
    }
}


?>